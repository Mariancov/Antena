self.addEventListener('fetch', function(event) {
  // Basic service worker (optional for PWA install)
});